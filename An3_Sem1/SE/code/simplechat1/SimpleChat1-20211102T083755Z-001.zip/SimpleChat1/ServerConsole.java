
import java.io.*;
import common.ChatIF;
import com.lloseng.ocsf.server.*;
import java.util.StringTokenizer;

public class ServerConsole implements ChatIF {

	final public static int DEFAULT_PORT = 5555;
	EchoServer server;
	public ServerConsole(int port){
		server=new EchoServer(port);
	}
	
	
	public void readCommand(String msg) {
		if (msg.equals("#quit")) {
			try{
				System.exit(0);
				//server.close();
			} catch(Exception e){
				System.out.println("Could not close server");
			}
		}
		else
			if (msg.equals("#stop"))
			{
				server.stopListening();
			}
			else
				if(msg.equals("#close"))
				{
					//server.stopListening();
					//server.sendToAllClients("#logoff");
					try{
						server.close();
					} catch(IOException e){
						System.out.println("Could not close server");
					}
				}
				else
					if(msg.equals("#start"))
					{
						if(server.isListening()==true)
							System.out.println("Error: Server is already listening");
						else
						{
							try {
								server.listen();
							}catch(IOException e){
								System.out.println("Error: could not start server");
							}
						}
					}
					else
						if(msg.equals("#getport"))
							System.out.println(server.getPort());
						else
						{
							StringTokenizer st = new StringTokenizer(msg," ");
							String command = st.nextToken();
							String param = st.nextToken();
							if(command.equals("#setport"))
							{
								if(server.isClosed())
								{
									int port = Integer.parseInt(param);
									server.setPort(port);
								}
								else
									System.out.println("Error: Server is not closed");
								
							}
						}
	}
	
	
	
	public void accept() {
		try {
			server.listen();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Error: Could not listen for clients");
		}
		try{
			BufferedReader fromConsole = 
				new BufferedReader(new InputStreamReader(System.in));
			String message;

			while (true) {
				message = fromConsole.readLine();
				if(message.charAt(0)=='#'){
					this.readCommand(message);
				}
				else display(message);
			}
		} catch (Exception ex) {
			System.out.println("Unexpected error while reading from console!");
		}
	}
	
	
	@Override
	public void display(String message) {
		System.out.println(">"+message);
		server.sendToAllClients("SERVER MSG> "+message);
	}
	
	public static void main(String[] args){
		int port = 0; // The port number

		try {
			port = Integer.parseInt(args[0]); // Get port from command line
		} catch (Throwable t) {
			port = DEFAULT_PORT; // Set port to 5555
		}

		ServerConsole server = new ServerConsole(port);
		server.accept();
	}

}
